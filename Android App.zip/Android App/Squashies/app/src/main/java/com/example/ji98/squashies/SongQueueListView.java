package com.example.ji98.squashies;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;

public class SongQueueListView extends BaseAdapter implements ListAdapter {
    private ArrayList<Songs> queuePostArrayList;
    private Context context;
    private TextView currentSongText;

    ListView currentQueue;


    public SongQueueListView(Context context, ArrayList<Songs> queuePostArrayList){
        this.context = context;
        this.queuePostArrayList = queuePostArrayList;
    }

    public void setParentView(ListView parent) {
        currentQueue = parent;
    }

    @Override
    public int getCount() {
        return queuePostArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return queuePostArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.currentqueuelistview, null);
        }

        //Handle TextView and display string into the current queue listview
        currentSongText = (TextView)view.findViewById(R.id.songText);
        currentSongText.setText(queuePostArrayList.get(position).getSongName());

        return view;
    }
}
