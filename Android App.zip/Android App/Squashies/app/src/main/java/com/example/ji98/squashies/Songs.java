package com.example.ji98.squashies;

import com.google.gson.annotations.SerializedName;

class Songs {
    @SerializedName("@ro")
    private String ro;

    @SerializedName("@name")
    private String songName;

    @SerializedName("@mobileID")
    private int songID;

    @SerializedName("@duration")
    private int duration;

    @SerializedName("@uri")
    private String uri;

    private String queuer;

    public String getRo() {
        return ro;
    }

    public String getSongName() {
        return songName;
    }

    public int getSongID() {
        return songID;
    }

    public String getQueuer(){
        return queuer;
    }

    public void setSongName(String name) {
        songName = name;
    }

    public int getDuration() {
        return duration;
    }

    public String getUri() {
        return uri;
    }
}
