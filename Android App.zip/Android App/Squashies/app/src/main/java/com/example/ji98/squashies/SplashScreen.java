package com.example.ji98.squashies;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Timer;
import java.util.TimerTask;
import static android.widget.Toast.LENGTH_SHORT;

public class SplashScreen extends AppCompatActivity {
    private static int SPLASH_TIME_OUT = 3000;
    ProgressBar pb;
    int counter = 0;

    private EditText textIPAddress;
    private TextView textView;
    private Button saveBtn;

    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String TEXT = "text";
    private String text;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splashscreen);

        textIPAddress = (EditText)findViewById(R.id.ipAddress_input);
        saveBtn = (Button)findViewById(R.id.enterIPBtn);

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateIPAddress()){
                    saveData();
                    prog();
                    run();
                }
            }
        });

        loadData();
        updateViews();
    }

    public void prog() {
        pb = (ProgressBar)findViewById(R.id.progressBar);
        pb.setVisibility(View.VISIBLE);
        final Timer t = new Timer();
        TimerTask tt = new TimerTask() {
            @Override
            public void run() {
                counter++;
                pb.setProgress(counter);

                if(counter == 100){
                    t.cancel();
                }
            }
        };

        t.schedule(tt, 0, 100);
    }


    public void saveData(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString(TEXT, textIPAddress.getText().toString());
        editor.apply();

        Toast.makeText(this, "Connecting to Squashie's Server", LENGTH_SHORT).show();

    }

    public void loadData(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        text = sharedPreferences.getString(TEXT, "");

    }

    public void updateViews(){
        textIPAddress.setText(text);
    }

    public boolean validateIPAddress(){
        text = textIPAddress.getText().toString().trim();
        if (!Patterns.IP_ADDRESS.matcher(text).matches()) {
            Toast.makeText(this, "Invalid IP Address", LENGTH_SHORT).show();
            return false;
        } else {

            return true;
        }
    }

    public void run(){
        //Loading up the splash screen for 3 seconds when app is first opened
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent homeIntent = new Intent(SplashScreen.this, MainActivity.class);
                startActivity(homeIntent);
                finish();

            }
        },SPLASH_TIME_OUT);
    }

}


