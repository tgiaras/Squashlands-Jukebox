package com.example.ji98.squashies;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.MODE_PRIVATE;
import static com.example.ji98.squashies.SplashScreen.SHARED_PREFS;
import static com.example.ji98.squashies.SplashScreen.TEXT;

public class MyCustomerAdapter extends BaseAdapter implements ListAdapter {
    private ArrayList<Post> dataModelArrayList;
    private Context context;
    private LayoutInflater inflater;
    private EditText txt_Input;
    private TextView songList;

    //The two parameters needed for the Add Song to Queue Retrofit
    private int currentSongID;
    private String queuer;

    //For the Current Listview/SongQueueListView class
    private JsonPlaceholderApi jsonPlaceholderApi;
    ArrayList<String> currentQueueArrayList = new ArrayList<String>();
    ArrayList<Songs> songs = new ArrayList<Songs>();
    ListView songQueueList;

    public MyCustomerAdapter(Context context, ArrayList<Post> dataModelArrayList) {
          this.context = context;
          this.dataModelArrayList = dataModelArrayList;

    }

    public void setParentView(ListView parent) {
        songQueueList = parent;
    }


    public void update(ArrayList<Post> results){
        dataModelArrayList = new ArrayList<Post>();
        dataModelArrayList.addAll(results);
        //indicates android that our listview needs to get refreshed and the listview gets refreshed immediately with current arraylist
        notifyDataSetChanged();
    }

    @Override
    public int getCount() { return dataModelArrayList.size(); }

    @Override
    public Object getItem(int position) {
        return dataModelArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.customlistadapter, null);
        }

        //Handle TextView and display string from your list
        songList = (TextView)view.findViewById(R.id.searchText);
        songList.setText(dataModelArrayList.get(position).getSongName());

        //Intent for the ipAddress to add song to queue
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        String ipAddress = sharedPreferences.getString(TEXT, "");

        // Retrofit to Add Song to the Queue - Establishing connection to the Web Server
        Retrofit addSong = new Retrofit.Builder()
                .baseUrl("http://" + ipAddress + ":5000/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        jsonPlaceholderApi = addSong.create(JsonPlaceholderApi.class);


        //Handle buttons and add onClickListeners
        ImageButton addBtn = (ImageButton)view.findViewById(R.id.addBtn);

        //Setting ID's to each ImageButton to match the Song ID
        if(addBtn != null) {
            addBtn.setTag(dataModelArrayList.get(position).getSongID());
            addBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Dynamically assigns the song ID with the "Add Button"
                    currentSongID = (int) v.getTag();
                    showDialog(v);
                }
            });
        }
        return view;
    }

    // Displays message to user that the song is added to the queue
    private void showToast(){
        LayoutInflater toastInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View toastView = toastInflater.inflate(R.layout.toast_layout, null);

        Toast toast = new Toast(context.getApplicationContext());
        toast.setGravity(Gravity.CENTER, 0,0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(toastView);

        toast.show();
    }

    // When Ro = 201, this is the error that will display "Song Already in Queue"
    private void showErrorToast(){
        LayoutInflater songAlreadyInQueueInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View errorView = songAlreadyInQueueInflater.inflate(R.layout.error_toastmessage, null);

        Toast errorToast = new Toast(context.getApplicationContext());
        errorToast.setGravity(Gravity.CENTER, 0,0);
        errorToast.setDuration(Toast.LENGTH_LONG);
        errorToast.setView(errorView);

        errorToast.show();
    }

    // When Ro = 202, this is the error that will display "Song Queue is Full"
    private void songQueueFullError(){
        LayoutInflater queueFullInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View songQueueFullView = queueFullInflater.inflate(R.layout.error_toastmessage, null);

        TextView toastText = songQueueFullView.findViewById(R.id.toast_text);
        toastText.setText("Queue is Full");

        Toast queueFullToast = new Toast(context.getApplicationContext());
        queueFullToast.setGravity(Gravity.CENTER, 0,0);
        queueFullToast.setDuration(Toast.LENGTH_LONG);
        queueFullToast.setView(songQueueFullView);

        queueFullToast.show();
    }

    private void emptyNameError(){
        LayoutInflater emptyName = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View name = emptyName.inflate(R.layout.error_toastmessage, null);

        TextView toastText = name.findViewById(R.id.toast_text);
        toastText.setText("Enter Valid Name");

        Toast nameToast = new Toast(context.getApplicationContext());
        nameToast.setGravity(Gravity.CENTER, 0,0);
        nameToast.setDuration(Toast.LENGTH_SHORT);
        nameToast.setView(name);

        nameToast.show();
    }


    // When someone clicks on the add button, an alert dialog will appear asking for the user to submit their name
    private void showDialog(View view){
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        final AlertDialog.Builder alert = new AlertDialog.Builder(context);
        View mView = inflater.inflate(R.layout.custom_dialog, null);

        txt_Input = (EditText)mView.findViewById(R.id.txt_input);
        Button btn_cancel = (Button)mView.findViewById(R.id.btn_cancel);
        Button btn_submit = (Button)mView.findViewById(R.id.btn_submit);

        alert.setView(mView);

        final AlertDialog alertDialog = alert.create();
        alertDialog.setCanceledOnTouchOutside(false);


        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                queuer = txt_Input.getText().toString();

                if(queuer.isEmpty()){
                    emptyNameError();
                } else

                    addSongToQueue();
                    alertDialog.dismiss();

            }
        });

        alertDialog.show();
    }

    // Adding a song into the queue when a song has been chosen and the name has been entered
    private void addSongToQueue(){
        Call<Songs> call = jsonPlaceholderApi.getSongID(currentSongID,queuer);
        call.enqueue(new Callback<Songs>() {
            @Override
            public void onResponse(Call<Songs> call, Response<Songs> response) {
                if(!response.isSuccessful()){
                    currentQueueArrayList.add("Code: " + response.code());
                    return;
                }

                String x = response.body().getRo();
                switch(x){
                    case "200":
                        Songs tempSong = new Songs();
                        tempSong.setSongName(response.body().getSongName());
                        songs.add(tempSong);
                        showToast();
                        break;
                    case "201":
                        showErrorToast();
                        break;
                    case "202":
                        songQueueFullError();
                        break;
                }

                // Updates the playlist
                songQueueList.refreshDrawableState();
            }

            @Override
            public void onFailure(Call<Songs> call, Throwable throwable) {
                currentQueueArrayList.add(throwable.getMessage());
                System.out.println(throwable);
            }
        });
    }
}
