package com.example.ji98.squashies;

public class RequestSong {

    private String patronName;
    private String songName;
    private String emailAddress;

    public String getPatronName() {
        return patronName;
    }

    public String getSongName() {
        return songName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setPatronName(String patronName) {
        this.patronName = patronName;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }




}
