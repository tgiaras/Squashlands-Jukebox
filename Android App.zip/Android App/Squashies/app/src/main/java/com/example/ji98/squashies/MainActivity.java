package com.example.ji98.squashies;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.example.ji98.squashies.SplashScreen.SHARED_PREFS;
import static com.example.ji98.squashies.SplashScreen.TEXT;

// MIT LICENCE AGREEMENT
// Copyright <2020> <Joshua Incollingo, Themis Giaras, Dharmjit Kailay>
//Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files
//(the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge,
// publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so,
// subject to the following conditions:
    // The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
    // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    //FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    // LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
    //IN THE SOFTWARE.

public class MainActivity extends AppCompatActivity {
    ListView mySongPlaylist, songQueueList;
    private JsonPlaceholderApi jsonPlaceholderApi;

    SearchView mySearchView;
    TextView marquee;

    //Adapter for the SongPlaylist
    MyCustomerAdapter adapter;

    //Adapter for the Current List Queue
    SongQueueListView newAdapter;

    Button requestBtn;

    //Song Playlist
    ArrayList<String> songPlaylist = new ArrayList<String>();

    ArrayList<Post> posts = new ArrayList<Post>();
    ArrayList<Songs> songs = new ArrayList<Songs>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        requestBtn = findViewById(R.id.requestPageButton);
        marquee = findViewById(R.id.marqueeText);
        marquee.setSelected(true);

        //Searchview and Listview for where users can see the songs and pick one
        mySearchView = findViewById(R.id.searchview);
        mySongPlaylist = findViewById(R.id.listview);

        //Current Queue Listview
        songQueueList = findViewById(R.id.currentQueueListview);

        //Retrieving IP address from Splash screen
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        String ipAddress = sharedPreferences.getString(TEXT, "");


        //Creating the Retrofit where the app retrieves the song playlist data from the web server
        Retrofit getSongs = new Retrofit.Builder()
                .baseUrl("http://"+ ipAddress +":5000/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        jsonPlaceholderApi = getSongs.create(JsonPlaceholderApi.class);

        //Retrofit Methods
        retrieveSongs();
        retrieveQueue();

        //Initalising the Song Playlist and Setting to the Adapter
        adapter = new MyCustomerAdapter(this, posts);
        adapter.setParentView(mySongPlaylist);
        mySongPlaylist.setAdapter(adapter);

        //Instantiate the Current Queue ListView and Setting to the Adapter
        newAdapter = new SongQueueListView(this, songs);
        newAdapter.setParentView(songQueueList);
        songQueueList.setAdapter(newAdapter);


        // Goes to the Request Song Not on Playlist Page
        requestBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToRequestPage();
            }
        });

        //This controls the searchview - when someone is typing in a song name through the searchview
        mySearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            // This gets called with every new input string
            public boolean onQueryTextChange(String newText) {
                ArrayList<Post>filteredOutput = new ArrayList<Post>();

                for(Post x: posts){
                    if(x.getSongName().toLowerCase().contains(newText.toLowerCase())){
                        filteredOutput.add(x);
                        }
                    }
                    //To refresh listview
                    ((MyCustomerAdapter)mySongPlaylist.getAdapter()).update(filteredOutput);
                    return false;
                }
        });
    }

    private void goToRequestPage(){
        Intent intent = new Intent(this, RequestSongNotOnPlaylist.class);
        startActivity(intent);
    }

    private void retrieveSongs(){
        Call<List<Post>> call = jsonPlaceholderApi.getPosts();
        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                if(!response.isSuccessful()){
                    songPlaylist.add("Code: " + response.code());
                    return;
                }

                for (Post post : response.body()){
                    //Here is where I add the songs into the listview properly!
                    posts.add(post);
                }
                // Updates the playlist
                mySongPlaylist.refreshDrawableState();

            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable throwable) {
                songPlaylist.add(throwable.getMessage());
                System.out.println(throwable);
            }
        });
    }

    private void retrieveQueue(){
        Call<List<Songs>> call = jsonPlaceholderApi.getQueue("true");
        call.enqueue(new Callback<List<Songs>>() {
            @Override
            public void onResponse(Call<List<Songs>> call, Response<List<Songs>> response) {
                if(!response.isSuccessful()){
                    songPlaylist.add("Code: " + response.code());
                    return;
                }

                for (Songs s : response.body()){
                    //Here is where I add the songs into the listview properly!
                    songs.add(s);
                }

                // Updates the playlist
                songQueueList.refreshDrawableState();

                // Repeats the method every 10 seconds
                refresh(10000);
            }

            @Override
            public void onFailure(Call<List<Songs>> call, Throwable throwable) {
                songPlaylist.add(throwable.getMessage());
                System.out.println(throwable);
            }
        });
    }

    private void refresh(int milliseconds){
        final Handler handler = new Handler();
        final Runnable runnable = new Runnable(){

            @Override
            public void run() {
                // Clears the playlist and then recalls the retrieve queue method to display the current queue
                songs.clear();
                retrieveQueue();
            }
        };

        handler.postDelayed(runnable, milliseconds);
    }
}