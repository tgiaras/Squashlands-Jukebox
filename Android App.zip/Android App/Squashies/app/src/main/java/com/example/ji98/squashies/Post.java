package com.example.ji98.squashies;

import com.google.gson.annotations.SerializedName;

public class Post {
    @SerializedName("@ro")
    private String ro;

    @SerializedName("@name")
    private String songName;

    @SerializedName("@id")
    private int songID;

    @SerializedName("@duration")
    private int duration;

    @SerializedName("@uri")
    private String uri;

    public Post(String songName, int songID) {
        this.songName = songName;
        this.songID = songID;
    }

    public String getRo() {
        return ro;
    }

    public String getSongName() {
        return songName;
    }

    public int getSongID() {
        return songID;
    }

    public int getDuration() {
        return duration;
    }

    public String getUri() {
        return uri;
    }

    public void setRo(String ro) {
        this.ro = ro;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }

    public void setSongID(int songID) {
        this.songID = songID;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }
}
