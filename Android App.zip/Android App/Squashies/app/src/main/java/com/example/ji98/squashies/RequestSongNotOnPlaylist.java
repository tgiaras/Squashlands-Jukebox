package com.example.ji98.squashies;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Patterns;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import static com.example.ji98.squashies.SplashScreen.SHARED_PREFS;
import static com.example.ji98.squashies.SplashScreen.TEXT;

public class RequestSongNotOnPlaylist extends AppCompatActivity {
    Button submitRequestBtn;
    Button backToHomeBtn;

    private TextInputLayout textInputEmail;
    private TextInputLayout songName;
    private TextInputLayout patronName;

    JsonPlaceholderApi jsonPlaceholderApi;

    //Parameters needed for the Retrofit call method
    private String emailString;
    private String songString;
    private String patronString;

    ArrayList<RequestSong> requests = new ArrayList<RequestSong>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.requestsongnotonplaylist);

        submitRequestBtn = findViewById(R.id.submitRequestButton);
        backToHomeBtn = findViewById(R.id.backToHomeButton);

        textInputEmail = findViewById(R.id.text_input_email);
        songName = findViewById(R.id.text_input_songName);
        patronName = findViewById(R.id.text_input_patronName);


        //Intent for the ipAddress to add song to queue
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        String ipAddress = sharedPreferences.getString(TEXT, "");

        // Retrofit to Add Song to the Queue - Establishing connection to the Web Server
        Retrofit addRequest = new Retrofit.Builder()
                .baseUrl("http://" + ipAddress + ":5000/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        jsonPlaceholderApi = addRequest.create(JsonPlaceholderApi.class);

        // Proceeds back to home page
        backToHomeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goBackToHomePage();
            }
        });

        // Submits the request and sends it to the database
        submitRequestBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateEmail()&& validateSongName() && validatePatronName()){
                    addData();
                    goBackToHomePage();
                }
            }
        });
    }

    // Required input for the patron name
    public boolean validatePatronName(){
        patronString = patronName.getEditText().getText().toString().trim();
        if(patronString.isEmpty()){
            patronName.setError("Field Can't Be Empty");
            return false;
        } else {
            patronName.setError(null);
            return true;
        }

    }

    // Required input for the song name
    public boolean validateSongName(){
        songString = songName.getEditText().getText().toString().trim();
        if(songString.isEmpty()){
            songName.setError("Field Can't Be Empty");
            return false;
        } else {
            songName.setError(null);
            return true;
        }
    }

    // Validates email address
    public boolean validateEmail(){
        emailString = textInputEmail.getEditText().getText().toString().trim();

        if(emailString.isEmpty()){
            textInputEmail.setError("Field Can't Be Empty");
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(emailString).matches()){
            textInputEmail.setError("Please Enter a Valid Email Address");
            return false;
        } else {
            textInputEmail.setError(null);
            return true;
        }
    }

    public void goBackToHomePage(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void showToast(){
        LayoutInflater toastInflater = getLayoutInflater();
        View toastView = toastInflater.inflate(R.layout.toast_layout, null);

        TextView toastText = toastView.findViewById(R.id.toast_text);
        toastText.setText("Request Sent");

        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.CENTER, 0,0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(toastView);

        toast.show();
    }

    public void addData(){
        Call<RequestSong>
                call = jsonPlaceholderApi.sendRequest(patronString,songString,emailString);
        call.enqueue(new Callback<RequestSong>() {
            @Override
            public void onResponse(Call<RequestSong> call, Response<RequestSong> response) {
                if(!response.isSuccessful()){
                    System.out.println("Code: " + response.code());
                    return;
                }

                RequestSong tempRequest = new RequestSong();
                tempRequest.setPatronName(response.body().getPatronName());
                tempRequest.setSongName(response.body().getSongName());
                tempRequest.setEmailAddress(response.body().getEmailAddress());
                requests.add(tempRequest);

                showToast();


            }

            @Override
            public void onFailure(Call<RequestSong> call, Throwable t) {
                System.out.println("Error: " + t.getMessage());

            }
        });
    }

}
