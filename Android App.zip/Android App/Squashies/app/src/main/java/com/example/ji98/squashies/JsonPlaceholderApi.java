package com.example.ji98.squashies;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface JsonPlaceholderApi {
    @GET("mediaLibrary.json")
    Call<List<Post>> getPosts();

    @GET("Songs")
    Call<Songs> getSongID(@Query("mobileID") int songID, @Query("queuer") String queuer);

    @GET("mediaLibrary.json")
    Call<List<Songs>> getQueue(@Query("queue") String songQueue);

    @GET("Requests")
    Call<RequestSong>sendRequest(@Query("patronName") String patronName, @Query("songName") String songName, @Query("emailAddress") String emailAddress);

}
